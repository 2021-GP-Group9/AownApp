package com.example.aownapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
