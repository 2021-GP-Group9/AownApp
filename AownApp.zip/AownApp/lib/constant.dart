class constant {
  static String url="https://awoon.000webhostapp.com/signup_screen.php";
  static String login_url="https://awoon.000webhostapp.com/login_screen.php";
      static int responseok=200;
}