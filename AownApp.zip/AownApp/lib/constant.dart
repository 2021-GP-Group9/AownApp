class constant {
  static String url = "https://awoon.000webhostapp.com/signup_screen.php";
  static String login_url = "https://awoon.000webhostapp.com/login_screen.php";
  static String profile_url = "https://awoon.000webhostapp.com/fetch_data.php";
  static String update_url = "https://awoon.000webhostapp.com/update_data.php";
  static String bookAppointmentUrl = "https://awoon.000webhostapp.com/book_appointement.php";
  static String getBookAppointmentUrl = "https://awoon.000webhostapp.com/get_book_appointment.php";
  static int responseok = 200;
}