import 'package:get/get.dart';
//store donor id
class ConstantController extends GetxController{
  String? donorId;
}